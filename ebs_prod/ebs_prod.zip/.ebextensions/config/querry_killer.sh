#!/bin/bash
aws s3 cp s3://vvalk-s3-ebs/.my.cnf /root/.my.cnf


LOG=/tmp/kill_mysql.log
SECONDS=10
ADDRESS=vvalk-ebs-ident.cymduwjml2u5.eu-west-2.rds.amazonaws.com

echo "####" `date` "####" > ${LOG}
PIDS=$(mysql  -h $ADDRESS -t -e 'show full processlist' | awk -F'|' -v seconds="$SECONDS" '$7 > seconds  && toupper($9) ~ /^ SELECT/ {print $0}' | tee -a $LOG | awk -F'|' '{print $2}')
[ -n "$PIDS" ] && mysqladmin -h $ADDRESS kill `echo $PIDS | tr ' ' ','`

